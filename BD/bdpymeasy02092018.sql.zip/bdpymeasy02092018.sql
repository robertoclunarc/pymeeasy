-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 03-09-2018 a las 01:39:49
-- Versión del servidor: 5.5.8
-- Versión de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `bdpymeasy`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_abonos`
--

CREATE TABLE IF NOT EXISTS `tbl_abonos` (
  `idabono` int(11) NOT NULL AUTO_INCREMENT,
  `fkventa` int(11) NOT NULL,
  `monto` double(11,2) NOT NULL,
  `modalidad_pago` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha` date NOT NULL,
  `nro_referencia` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fkabono_en_cuenta` int(11) DEFAULT NULL,
  `estatus_abono` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idabono`),
  KEY `fkventa` (`fkventa`),
  KEY `fkabono_en_cuenta` (`fkabono_en_cuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_abonos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_auditorias`
--

CREATE TABLE IF NOT EXISTS `tbl_auditorias` (
  `idauditoria` int(11) NOT NULL AUTO_INCREMENT,
  `actividad` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `login` varchar(6) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`idauditoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=42 ;

--
-- Volcar la base de datos para la tabla `tbl_auditorias`
--

INSERT INTO `tbl_auditorias` (`idauditoria`, `actividad`, `login`, `fecha`) VALUES
(1, 'Nuevo inicio de sesion', 'rlunar', '2018-08-24 16:26:43'),
(2, 'Registro de Nuevo Cliente: prueba 1', 'rlunar', '2018-08-24 18:29:22'),
(3, 'Actualizacion del registro Cliente: prueba 1.1', 'rlunar', '2018-08-24 19:35:57'),
(4, 'Registro de Nuevo Cliente: VICTOR SANVICENTE', 'rlunar', '2018-08-24 20:10:16'),
(5, 'Registro de Nuevo Cliente: COMERCIAL PEREZ', 'rlunar', '2018-08-24 20:11:02'),
(6, 'Registro de Nuevo Cliente: COMERCIAL EL ENCANTO', 'rlunar', '2018-08-24 20:13:51'),
(7, 'Registro de Nuevo Cliente: INVERSIONES AMISHA EXPR', 'rlunar', '2018-08-24 20:15:04'),
(8, 'Registro de Nuevo Cliente: INVERSIONES J Y Y RONDO', 'rlunar', '2018-08-24 20:15:35'),
(9, 'Registro de Nuevo Cliente: INVERSIONES VAIVEN', 'rlunar', '2018-08-24 20:16:21'),
(10, 'Registro de Nuevo Cliente: INVERSIONES PALMA REAL', 'rlunar', '2018-08-24 20:16:53'),
(11, 'Actualizacion del registro Cliente: CHARCUTERIA PI', 'rlunar', '2018-08-24 20:30:39'),
(12, 'Actualizacion del registro Cliente: CHARCUTERIA PI', 'rlunar', '2018-08-24 20:31:14'),
(13, 'Nuevo inicio de sesion', 'rlunar', '2018-08-27 16:13:50'),
(14, 'Registro de Nuevo Cliente: prueba 2', 'rlunar', '2018-08-27 16:28:05'),
(15, 'Registro de Nuevo Proveedor: PRueva 3', 'rlunar', '2018-08-27 16:28:47'),
(16, 'Actualizacion del registro Cliente: PRueva 3', 'rlunar', '2018-08-27 17:12:17'),
(17, 'Actualizacion del registro Proveedor: PRueva 3', 'rlunar', '2018-08-27 17:30:37'),
(18, 'Actualizacion del registro Proveedor: PRueva 3', 'rlunar', '2018-08-27 17:56:23'),
(19, 'Actualizacion del registro Cliente: BODEGON PICHON', 'rlunar', '2018-08-27 18:10:17'),
(20, 'Registro de Nuevo Cliente: prueba 4', 'rlunar', '2018-08-27 19:58:43'),
(21, 'Nuevo inicio de sesion', 'rlunar', '2018-08-28 12:23:32'),
(22, 'Registro de Nuevo Vendedor: rueba 5p', 'rlunar', '2018-08-28 12:24:44'),
(23, 'Registro de Nuevo Vendedor: prueba vendedor 2', 'rlunar', '2018-08-28 12:36:40'),
(24, 'Nuevo inicio de sesion', 'rlunar', '2018-09-01 13:21:33'),
(25, 'Actualizacion del registro Vendedor: prueba vended', 'rlunar', '2018-09-01 14:44:48'),
(26, 'Actualizacion de Datos de Empresa', 'rlunar', '2018-09-01 15:50:08'),
(27, 'Actualizacion de Datos de Empresa', 'rlunar', '2018-09-01 15:50:53'),
(28, 'Nuevo inicio de sesion', 'rlunar', '2018-09-02 08:57:07'),
(29, 'Registro de Nueva Cta. Bancaria: ', 'rlunar', '2018-09-02 11:18:09'),
(30, 'Registro de Nueva Cta. Bancaria: 0', 'rlunar', '2018-09-02 11:19:01'),
(31, 'Registro de Nueva Cta. Bancaria: 0', 'rlunar', '2018-09-02 11:20:59'),
(32, 'Registro de Nueva Cta. Bancaria: 12345678909876543', 'rlunar', '2018-09-02 11:26:56'),
(33, 'Actualizacion de Cta. Bancaria: 123456789098765432', 'rlunar', '2018-09-02 11:31:05'),
(34, 'Registro de Nueva Cta. Bancaria: 1235', 'rlunar', '2018-09-02 11:34:20'),
(35, 'Actualizacion de Cta. Bancaria: 123456789098765432', 'rlunar', '2018-09-02 11:34:20'),
(36, 'Actualizacion de Cta. Bancaria: 123456789098765432', 'rlunar', '2018-09-02 11:34:30'),
(37, 'Actualizacion de Cta. Bancaria: 1235', 'rlunar', '2018-09-02 11:34:30'),
(38, 'Registro de producto: MORTADELA', 'rlunar', '2018-09-02 17:03:27'),
(39, 'Registro de producto: ARROZ', 'rlunar', '2018-09-02 17:13:25'),
(40, 'Registro de producto: HARINA DE TRIGO', 'rlunar', '2018-09-02 17:14:02'),
(41, 'Registro de producto: HARINA DE MAIZ', 'rlunar', '2018-09-02 17:16:18');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cierres_diarios_inv`
--

CREATE TABLE IF NOT EXISTS `tbl_cierres_diarios_inv` (
  `idcierre` int(11) NOT NULL AUTO_INCREMENT,
  `fkproducto` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `cantidad_unidad` int(11) NOT NULL,
  `cantidad_blt` int(11) NOT NULL,
  `observacion` varchar(500) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `responsable` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `estatus_cierre` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idcierre`),
  KEY `fkproducto` (`fkproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_cierres_diarios_inv`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_clientes`
--

CREATE TABLE IF NOT EXISTS `tbl_clientes` (
  `idcliente` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `razon_social` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `representante_legal` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fono` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `estatus_cliente` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`idcliente`),
  UNIQUE KEY `rif` (`rif`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=54 ;

--
-- Volcar la base de datos para la tabla `tbl_clientes`
--

INSERT INTO `tbl_clientes` (`idcliente`, `rif`, `razon_social`, `representante_legal`, `direccion`, `fono`, `email`, `estatus_cliente`) VALUES
(2, 'V12003177', 'VICTOR SANVICENTE', 'VICTOR SANVICENTE', '', '', '', 'ACTIVO'),
(3, 'COMERCIALPER', 'COMERCIAL PEREZ', 'COMERCIAL PEREZ', '', '', '', 'ACTIVO'),
(4, 'J306364234', 'COMERCIAL EL ENCANTO', 'COMERCIAL EL ENCANTO', '', '', '', 'ACTIVO'),
(5, 'J410151927', 'INVERSIONES AMISHA EXPRESS', 'INVERSIONES AMISHA EXPRESS', '', '', '', 'ACTIVO'),
(6, 'J41108384-4', 'INVERSIONES J Y Y RONDON ', 'INVERSIONES J Y Y RONDON ', '', '', '', 'ACTIVO'),
(7, 'J40566966', 'INVERSIONES VAIVEN', 'INVERSIONES VAIVEN', '', '', '', 'ACTIVO'),
(8, 'J296684073', 'INVERSIONES PALMA REAL', 'INVERSIONES PALMA REAL', '', '', '', 'ACTIVO'),
(9, 'J402474067', 'CARNICERIA EL TORO DE ORO', 'CARNICERIA EL TORO DE ORO', NULL, NULL, NULL, 'ACTIVO'),
(10, 'J307470615', 'EXQUISITESES PANADERIA SALTO ANGEL', 'EXQUISITESES PANADERIA SALTO ANGEL', NULL, NULL, NULL, 'ACTIVO'),
(11, 'J407844016', 'INVERSIONES ALLOPY', 'INVERSIONES ALLOPY', NULL, NULL, NULL, 'ACTIVO'),
(12, 'J407530763', 'DALIDY FESTEJOS Y SUMINISTROS C.A', 'DALIDY FESTEJOS Y SUMINISTROS C.A', NULL, NULL, NULL, 'ACTIVO'),
(13, 'V113363025', 'INVERSIONES JOSE MANUEL FIGUEROA URETRA', 'INVERSIONES JOSE MANUEL FIGUEROA URETRA', NULL, NULL, NULL, 'ACTIVO'),
(14, 'J298483229', 'CHARCUTERIA GL, C.A', 'CHARCUTERIA GL, C.A', NULL, NULL, NULL, 'ACTIVO'),
(15, 'J402862768', 'INVERSIONES MARCANO PEREZ', 'INVERSIONES MARCANO PEREZ', NULL, NULL, NULL, 'ACTIVO'),
(16, 'V110081185', 'OVI, C.A', 'OVI, C.A', NULL, NULL, NULL, 'ACTIVO'),
(17, 'J403117152', 'CHARCUTERIA PIÃ‘A', 'CHARCUTERIA PIÃ‘A', '', '', '', 'ACTIVO'),
(18, 'J405873922', 'INVERSIONES Y SERVICIOS YELI', 'INVERSIONES Y SERVICIOS YELI', NULL, NULL, NULL, 'ACTIVO'),
(19, 'J409707555', 'SUPERFERIA LA TOMATINA', 'SUPERFERIA LA TOMATINA', NULL, NULL, NULL, 'ACTIVO'),
(20, 'J409238652', 'RYGYN BODEGON', 'RYGYN BODEGON', NULL, NULL, NULL, 'ACTIVO'),
(21, 'J309655507', 'PANADERIA Y PASTELERIA ANA NELLY, C.A', 'PANADERIA Y PASTELERIA ANA NELLY, C.A', NULL, NULL, NULL, 'ACTIVO'),
(38, 'J403084165', 'BODEGON SAN ANTONIO', 'BODEGON SAN ANTONIO', NULL, NULL, NULL, 'ACTIVO'),
(39, 'J407510320', 'BODEGON PICHON', 'BODEGON PICHON', '', '', '', 'INACTIVO'),
(40, 'J312148578', 'CHARCUTERIA LOS HERMANOS', 'CHARCUTERIA LOS HERMANOS', NULL, NULL, NULL, 'ACTIVO'),
(41, 'V121261908', 'CHARCUTERIA KASUPO AMADO DAVID', 'CHARCUTERIA KASUPO AMADO DAVID', NULL, NULL, NULL, 'ACTIVO'),
(42, 'J407769308', 'INVERSIONES DAVI Y WILLIAN', 'INVERSIONES DAVI Y WILLIAN', NULL, NULL, NULL, 'ACTIVO'),
(43, 'J405655933', 'INVERSIONES LA POPULAR', 'INVERSIONES LA POPULAR', NULL, NULL, NULL, 'ACTIVO'),
(44, 'J408129035', 'CHARCUTERIA EL GRAN YO SOY', 'CHARCUTERIA EL GRAN YO SOY', NULL, NULL, NULL, 'ACTIVO'),
(45, 'V216769798', 'JULIE DEBRA', 'JULIE DEBRA', NULL, NULL, NULL, 'ACTIVO'),
(46, 'J407742850', 'MULTIVARIEDADES MIS DOS ESTRELLAS', 'MULTIVARIEDADES MIS DOS ESTRELLAS', NULL, NULL, NULL, 'ACTIVO'),
(47, 'J408729652', 'INVERSIONES MI PROVISION', 'INVERSIONES MI PROVISION', NULL, NULL, NULL, 'ACTIVO'),
(48, 'J40599830', 'INVERSIONES LA BEDICION DE DIOS', 'INVERSIONES LA BEDICION DE DIOS', NULL, NULL, NULL, 'ACTIVO'),
(49, 'KA VALLENILL', 'KA VALLENILLA', 'KA VALLENILLA', NULL, NULL, NULL, 'ACTIVO'),
(50, 'OVI, C.A', 'OVI, C.A', 'OVI, C.A', NULL, NULL, NULL, 'ACTIVO'),
(51, 'V113392157', 'LOS PANES DE ARELYS', 'LOS PANES DE ARELYS', NULL, NULL, NULL, 'ACTIVO'),
(52, '123456', 'prueba 2', 'prueba 2', 'prueba 2', 'prueba 2', 'prueba2@prueba.com', 'ACTIVO'),
(53, '1234567', 'prueba 4', '', 'NULL', 'prueba 4', 'prueba 4@prueba .cpm', 'ACTIVO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cuentas_bancarias`
--

CREATE TABLE IF NOT EXISTS `tbl_cuentas_bancarias` (
  `idcuenta_bnc` int(11) NOT NULL AUTO_INCREMENT,
  `nro_cuenta` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `banco` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `tipo` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idcuenta_bnc`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `tbl_cuentas_bancarias`
--

INSERT INTO `tbl_cuentas_bancarias` (`idcuenta_bnc`, `nro_cuenta`, `banco`, `tipo`) VALUES
(4, '12345678909876543219', 'pichincha', 'CORRIENTE'),
(5, '1235', 'pola', 'CORRIENTE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cuentas_cobrar`
--

CREATE TABLE IF NOT EXISTS `tbl_cuentas_cobrar` (
  `idcuenta_cob` int(11) NOT NULL AUTO_INCREMENT,
  `fkventa` int(11) NOT NULL,
  `monto_total` double(11,2) NOT NULL,
  `monto_debe` double(11,2) NOT NULL,
  `monto_haber` double(11,2) DEFAULT '0.00',
  `estatus` varchar(10) COLLATE utf8_spanish2_ci DEFAULT 'PENDIENTE',
  PRIMARY KEY (`idcuenta_cob`),
  KEY `fkventa` (`fkventa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_cuentas_cobrar`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cuentas_pagar`
--

CREATE TABLE IF NOT EXISTS `tbl_cuentas_pagar` (
  `idcuenta_pag` int(11) NOT NULL AUTO_INCREMENT,
  `fkventa` int(11) NOT NULL,
  `monto_total` double(11,2) NOT NULL,
  `monto_pagar` double(11,2) DEFAULT '0.00',
  `monto_debe` double(11,2) NOT NULL,
  `estatus_ctapag` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idcuenta_pag`),
  KEY `fkventa` (`fkventa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_cuentas_pagar`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_detalles_pedidos`
--

CREATE TABLE IF NOT EXISTS `tbl_detalles_pedidos` (
  `iddetalle_ped` int(11) NOT NULL AUTO_INCREMENT,
  `fkpedido` int(11) NOT NULL,
  `fkproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` double(11,2) NOT NULL,
  `precio_blt` double(11,2) NOT NULL,
  `subtotal` double(11,2) NOT NULL,
  `estatus_det_pedido` varchar(10) COLLATE utf8_spanish2_ci DEFAULT 'EN ESPERA',
  PRIMARY KEY (`iddetalle_ped`),
  KEY `fkpedido` (`fkpedido`),
  KEY `fkproducto` (`fkproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_detalles_pedidos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_detalles_ventas`
--

CREATE TABLE IF NOT EXISTS `tbl_detalles_ventas` (
  `fkventa` int(11) NOT NULL,
  `fkproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` double(11,2) NOT NULL,
  `precio_total` double(11,2) NOT NULL,
  KEY `fkproducto` (`fkproducto`),
  KEY `fkventa` (`fkventa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_detalles_ventas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_fletes`
--

CREATE TABLE IF NOT EXISTS `tbl_fletes` (
  `idflete` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `transportista` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `fkpedido` int(11) NOT NULL,
  `costo` double(11,2) NOT NULL,
  `estatus_flete` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idflete`),
  KEY `fkpedido` (`fkpedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_fletes`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_modalidades_pagos`
--

CREATE TABLE IF NOT EXISTS `tbl_modalidades_pagos` (
  `idmodalidad` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idmodalidad`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `tbl_modalidades_pagos`
--

INSERT INTO `tbl_modalidades_pagos` (`idmodalidad`, `descripcion`) VALUES
(1, 'TRANSFERENCIA'),
(2, 'DEPOSITO'),
(3, 'EFECTIVO'),
(4, 'TDD'),
(5, 'TDC'),
(6, 'CHEQUE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_nros_cuentas_vendedores`
--

CREATE TABLE IF NOT EXISTS `tbl_nros_cuentas_vendedores` (
  `fkvendedor` int(11) NOT NULL,
  `banco` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `cuenta` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `tipo_cuenta` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `estatus_cta_vend` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  KEY `fkvendedor` (`fkvendedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_nros_cuentas_vendedores`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_parametros`
--

CREATE TABLE IF NOT EXISTS `tbl_parametros` (
  `iva` double(11,2) DEFAULT NULL,
  `nombre_empresa` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `rif` varchar(12) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `direccion` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `ciudad` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `region` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `nombre_encargado` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fono` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_parametros`
--

INSERT INTO `tbl_parametros` (`iva`, `nombre_empresa`, `rif`, `direccion`, `ciudad`, `region`, `nombre_encargado`, `fono`) VALUES
(16.00, 'carmen moterola', '34543534-5', 'fm', 'Guayana', 'San Felix', 'Carmen Monterola', '0414-');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_pedidos`
--

CREATE TABLE IF NOT EXISTS `tbl_pedidos` (
  `idpedido` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_pedido` int(11) NOT NULL,
  `fkproveedor` int(11) NOT NULL,
  `forma_pago` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `nro_operacion` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fecha_llegada` date DEFAULT NULL,
  `subtotal` double(11,2) NOT NULL,
  `iva` double(11,2) NOT NULL,
  `total_pedido` double(11,2) NOT NULL,
  `estatus_pedido` varchar(10) COLLATE utf8_spanish2_ci DEFAULT 'EN ESPERA',
  PRIMARY KEY (`idpedido`),
  KEY `fkproveedor` (`fkproveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_pedidos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_precios_productos`
--

CREATE TABLE IF NOT EXISTS `tbl_precios_productos` (
  `fkproducto` int(11) NOT NULL,
  `precio_unitario` double(11,2) DEFAULT NULL,
  `precio_blt` double(11,2) DEFAULT NULL,
  KEY `fkproducto` (`fkproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_precios_productos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_productos`
--

CREATE TABLE IF NOT EXISTS `tbl_productos` (
  `idproducto` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_prod` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `marca` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `cantidad_unitaria` int(11) NOT NULL,
  `cantidad_blt` int(11) NOT NULL,
  `cant_unidades_en_blt` int(11) NOT NULL,
  `estatus_prod` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`idproducto`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `tbl_productos`
--

INSERT INTO `tbl_productos` (`idproducto`, `descripcion_prod`, `marca`, `cantidad_unitaria`, `cantidad_blt`, `cant_unidades_en_blt`, `estatus_prod`) VALUES
(1, 'MORTADELA', 'PLUMBROSES', 0, 0, 20, 'INACTIVO'),
(2, 'ARROZ', 'MARY', 0, 0, 20, 'INACTIVO'),
(3, 'HARINA DE TRIGO', 'ROBIN HUB', 0, 0, 20, 'INACTIVO'),
(4, 'HARINA DE MAIZ', 'PAN', 0, 0, 20, 'INACTIVO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_proveedores`
--

CREATE TABLE IF NOT EXISTS `tbl_proveedores` (
  `idproveedor` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `razon_social` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `representante_legal` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fono` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `estatus_prov` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`idproveedor`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `tbl_proveedores`
--

INSERT INTO `tbl_proveedores` (`idproveedor`, `rif`, `razon_social`, `representante_legal`, `direccion`, `fono`, `email`, `estatus_prov`) VALUES
(1, '123456789', 'PRueva 3', 'PRueva 3', 'PRueva 3', 'PRueva 3', 'PRueba3@prueba.com', 'ACTIVO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_regalias`
--

CREATE TABLE IF NOT EXISTS `tbl_regalias` (
  `idregalia` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `descripcion` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `responsable` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fkproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `estatus_reg` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idregalia`),
  KEY `fkproducto` (`fkproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_regalias`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuarios`
--

CREATE TABLE IF NOT EXISTS `tbl_usuarios` (
  `login` varchar(6) COLLATE utf8_spanish2_ci NOT NULL,
  `passw` varchar(32) COLLATE utf8_spanish2_ci NOT NULL,
  `user_name` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `nivel` int(11) NOT NULL,
  `email` varchar(80) COLLATE utf8_spanish2_ci NOT NULL,
  `pregunta_secreta_1` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `respuesta_secreta_1` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `pregunta_secreta_2` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `respuesta_secreta_2` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `estatus_user` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_usuarios`
--

INSERT INTO `tbl_usuarios` (`login`, `passw`, `user_name`, `nivel`, `email`, `pregunta_secreta_1`, `respuesta_secreta_1`, `pregunta_secreta_2`, `respuesta_secreta_2`, `estatus_user`) VALUES
('rlunar', '827ccb0eea8a706c4c34a16891f84e7b', 'Roberto Lunar', 1, 'roberto_lunar@yahoo.', '-', '-', '-', '-', 'ACTIVO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_vendedores`
--

CREATE TABLE IF NOT EXISTS `tbl_vendedores` (
  `idvendedor` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `nombres` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fono` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `estatus_vend` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`idvendedor`),
  UNIQUE KEY `rif` (`rif`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `tbl_vendedores`
--

INSERT INTO `tbl_vendedores` (`idvendedor`, `rif`, `nombres`, `email`, `fono`, `estatus_vend`) VALUES
(1, '123456789', 'rueba 5p', 'rueba5p@prueba.com', 'rueba 5p', 'ACTIVO'),
(2, '1234567890', 'prueba vendedor 2', '00000', '00000', 'INACTIVO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_ventas`
--

CREATE TABLE IF NOT EXISTS `tbl_ventas` (
  `idventa` int(11) NOT NULL AUTO_INCREMENT,
  `fkvendedor` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `fkcliente` int(11) NOT NULL,
  `iva` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `subtotal` double(11,2) NOT NULL,
  `total_neto` double(11,2) NOT NULL,
  `excento` double(11,2) NOT NULL,
  `estatus_venta` varchar(10) COLLATE utf8_spanish2_ci NOT NULL COMMENT 'pendiente, pagada, anulada',
  PRIMARY KEY (`idventa`),
  KEY `fkcliente` (`fkcliente`),
  KEY `fkvendedor` (`fkvendedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_ventas`
--


-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_graficos_1`
--
CREATE TABLE IF NOT EXISTS `vw_graficos_1` (
`label` varchar(8)
,`dato` double(19,2)
);
-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_graficos_2`
--
CREATE TABLE IF NOT EXISTS `vw_graficos_2` (
`label` varchar(8)
,`dato` double(19,2)
);
-- --------------------------------------------------------

--
-- Estructura para la vista `vw_graficos_1`
--
DROP TABLE IF EXISTS `vw_graficos_1`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_graficos_1` AS select date_format(`tbl_ventas`.`fecha`,'%d-%m-%y') AS `label`,sum(`tbl_ventas`.`total_neto`) AS `dato` from `tbl_ventas` where ((cast(`tbl_ventas`.`fecha` as date) >= cast((now() - interval 7 day) as date)) and (`tbl_ventas`.`estatus_venta` = 'PAGADA')) group by date_format(`tbl_ventas`.`fecha`,'%d-%m-%y') order by `tbl_ventas`.`fecha`;

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_graficos_2`
--
DROP TABLE IF EXISTS `vw_graficos_2`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_graficos_2` AS select date_format(`tbl_pedidos`.`fecha_pedido`,'%d-%m-%y') AS `label`,sum(`tbl_pedidos`.`total_pedido`) AS `dato` from `tbl_pedidos` where ((cast(`tbl_pedidos`.`fecha_pedido` as date) >= cast((now() - interval 7 day) as date)) and (`tbl_pedidos`.`estatus_pedido` = 'PAGADO')) group by date_format(`tbl_pedidos`.`fecha_pedido`,'%d-%m-%y') order by `tbl_pedidos`.`fecha_pedido`;

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `tbl_abonos`
--
ALTER TABLE `tbl_abonos`
  ADD CONSTRAINT `tbl_abonos_ibfk_1` FOREIGN KEY (`fkventa`) REFERENCES `tbl_ventas` (`idventa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_cierres_diarios_inv`
--
ALTER TABLE `tbl_cierres_diarios_inv`
  ADD CONSTRAINT `tbl_cierres_diarios_inv_ibfk_1` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_cuentas_cobrar`
--
ALTER TABLE `tbl_cuentas_cobrar`
  ADD CONSTRAINT `tbl_cuentas_cobrar_ibfk_1` FOREIGN KEY (`fkventa`) REFERENCES `tbl_ventas` (`idventa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_cuentas_pagar`
--
ALTER TABLE `tbl_cuentas_pagar`
  ADD CONSTRAINT `tbl_cuentas_pagar_ibfk_1` FOREIGN KEY (`fkventa`) REFERENCES `tbl_ventas` (`idventa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_detalles_pedidos`
--
ALTER TABLE `tbl_detalles_pedidos`
  ADD CONSTRAINT `tbl_detalles_pedidos_ibfk_1` FOREIGN KEY (`fkpedido`) REFERENCES `tbl_pedidos` (`idpedido`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_detalles_pedidos_ibfk_2` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`);

--
-- Filtros para la tabla `tbl_detalles_ventas`
--
ALTER TABLE `tbl_detalles_ventas`
  ADD CONSTRAINT `tbl_detalles_ventas_ibfk_1` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`),
  ADD CONSTRAINT `tbl_detalles_ventas_ibfk_2` FOREIGN KEY (`fkventa`) REFERENCES `tbl_ventas` (`idventa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_fletes`
--
ALTER TABLE `tbl_fletes`
  ADD CONSTRAINT `tbl_fletes_ibfk_1` FOREIGN KEY (`fkpedido`) REFERENCES `tbl_pedidos` (`idpedido`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_nros_cuentas_vendedores`
--
ALTER TABLE `tbl_nros_cuentas_vendedores`
  ADD CONSTRAINT `tbl_nros_cuentas_vendedores_ibfk_1` FOREIGN KEY (`fkvendedor`) REFERENCES `tbl_vendedores` (`idvendedor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_pedidos`
--
ALTER TABLE `tbl_pedidos`
  ADD CONSTRAINT `tbl_pedidos_ibfk_1` FOREIGN KEY (`fkproveedor`) REFERENCES `tbl_proveedores` (`idproveedor`);

--
-- Filtros para la tabla `tbl_precios_productos`
--
ALTER TABLE `tbl_precios_productos`
  ADD CONSTRAINT `tbl_precios_productos_ibfk_1` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_regalias`
--
ALTER TABLE `tbl_regalias`
  ADD CONSTRAINT `tbl_regalias_ibfk_1` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`);

--
-- Filtros para la tabla `tbl_ventas`
--
ALTER TABLE `tbl_ventas`
  ADD CONSTRAINT `tbl_ventas_ibfk_1` FOREIGN KEY (`fkcliente`) REFERENCES `tbl_clientes` (`idcliente`),
  ADD CONSTRAINT `tbl_ventas_ibfk_2` FOREIGN KEY (`fkvendedor`) REFERENCES `tbl_vendedores` (`idvendedor`);
