-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 24-08-2018 a las 03:08:32
-- Versión del servidor: 5.5.8
-- Versión de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `bdpymeasy`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_abonos`
--

CREATE TABLE IF NOT EXISTS `tbl_abonos` (
  `idabono` int(11) NOT NULL AUTO_INCREMENT,
  `fkventa` int(11) NOT NULL,
  `monto` double(11,2) NOT NULL,
  `modalidad_pago` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha` date NOT NULL,
  `nro_referencia` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fkabono_en_cuenta` int(11) DEFAULT NULL,
  `estatus_abono` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idabono`),
  KEY `fkventa` (`fkventa`),
  KEY `fkabono_en_cuenta` (`fkabono_en_cuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_abonos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_auditorias`
--

CREATE TABLE IF NOT EXISTS `tbl_auditorias` (
  `idauditoria` int(11) NOT NULL AUTO_INCREMENT,
  `actividad` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `login` varchar(6) COLLATE utf8_spanish2_ci NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`idauditoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_auditorias`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cierres_diarios_inv`
--

CREATE TABLE IF NOT EXISTS `tbl_cierres_diarios_inv` (
  `idcierre` int(11) NOT NULL AUTO_INCREMENT,
  `fkproducto` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `cantidad_unidad` int(11) NOT NULL,
  `cantidad_blt` int(11) NOT NULL,
  `observacion` varchar(500) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `responsable` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `estatus_cierre` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idcierre`),
  KEY `fkproducto` (`fkproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_cierres_diarios_inv`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_clientes`
--

CREATE TABLE IF NOT EXISTS `tbl_clientes` (
  `idcliente` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `razon_social` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `representante_legal` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fono` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `estatus_cliente` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_clientes`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cuentas_bancarias`
--

CREATE TABLE IF NOT EXISTS `tbl_cuentas_bancarias` (
  `idcuenta_bnc` int(11) NOT NULL AUTO_INCREMENT,
  `nro_cuenta` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `banco` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `tipo` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idcuenta_bnc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_cuentas_bancarias`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cuentas_cobrar`
--

CREATE TABLE IF NOT EXISTS `tbl_cuentas_cobrar` (
  `idcuenta_cob` int(11) NOT NULL AUTO_INCREMENT,
  `fkventa` int(11) NOT NULL,
  `monto_total` double(11,2) NOT NULL,
  `monto_debe` double(11,2) NOT NULL,
  `monto_haber` double(11,2) DEFAULT '0.00',
  `estatus` varchar(10) COLLATE utf8_spanish2_ci DEFAULT 'PENDIENTE',
  PRIMARY KEY (`idcuenta_cob`),
  KEY `fkventa` (`fkventa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_cuentas_cobrar`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cuentas_pagar`
--

CREATE TABLE IF NOT EXISTS `tbl_cuentas_pagar` (
  `idcuenta_pag` int(11) NOT NULL AUTO_INCREMENT,
  `fkventa` int(11) NOT NULL,
  `monto_total` double(11,2) NOT NULL,
  `monto_pagar` double(11,2) DEFAULT '0.00',
  `monto_debe` double(11,2) NOT NULL,
  `estatus_ctapag` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idcuenta_pag`),
  KEY `fkventa` (`fkventa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_cuentas_pagar`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_detalles_pedidos`
--

CREATE TABLE IF NOT EXISTS `tbl_detalles_pedidos` (
  `iddetalle_ped` int(11) NOT NULL AUTO_INCREMENT,
  `fkpedido` int(11) NOT NULL,
  `fkproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` double(11,2) NOT NULL,
  `precio_blt` double(11,2) NOT NULL,
  `subtotal` double(11,2) NOT NULL,
  PRIMARY KEY (`iddetalle_ped`),
  KEY `fkpedido` (`fkpedido`),
  KEY `fkproducto` (`fkproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_detalles_pedidos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_detalles_ventas`
--

CREATE TABLE IF NOT EXISTS `tbl_detalles_ventas` (
  `fkventa` int(11) NOT NULL,
  `fkproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` double(11,2) NOT NULL,
  `precio_total` double(11,2) NOT NULL,
  KEY `fkproducto` (`fkproducto`),
  KEY `fkventa` (`fkventa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_detalles_ventas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_fletes`
--

CREATE TABLE IF NOT EXISTS `tbl_fletes` (
  `idflete` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `transportista` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `fkpedido` int(11) NOT NULL,
  `costo` double(11,2) NOT NULL,
  `estatus_flete` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idflete`),
  KEY `fkpedido` (`fkpedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_fletes`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_modalidades_pagos`
--

CREATE TABLE IF NOT EXISTS `tbl_modalidades_pagos` (
  `idmodalidad` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idmodalidad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_modalidades_pagos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_nros_cuentas_vendedores`
--

CREATE TABLE IF NOT EXISTS `tbl_nros_cuentas_vendedores` (
  `fkvendedor` int(11) NOT NULL,
  `banco` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `cuenta` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `tipo_cuenta` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `estatus_cta_vend` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  KEY `fkvendedor` (`fkvendedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_nros_cuentas_vendedores`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_parametros`
--

CREATE TABLE IF NOT EXISTS `tbl_parametros` (
  `iva` double(11,2) DEFAULT NULL,
  `nombre_empresa` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `rif` varchar(12) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `direccion` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `ciudad` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `region` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `nombre_encargado` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fono` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_parametros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_pedidos`
--

CREATE TABLE IF NOT EXISTS `tbl_pedidos` (
  `idpedido` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_pedido` int(11) NOT NULL,
  `fkproveedor` int(11) NOT NULL,
  `forma_pago` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `nro_operacion` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `subtotal` double(11,2) NOT NULL,
  `iva` double(11,2) NOT NULL,
  `total_pedido` double(11,2) NOT NULL,
  `estatus_pedido` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idpedido`),
  KEY `fkproveedor` (`fkproveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_pedidos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_precios_productos`
--

CREATE TABLE IF NOT EXISTS `tbl_precios_productos` (
  `fkproducto` int(11) NOT NULL,
  `precio_unitario` double(11,2) DEFAULT NULL,
  `precio_blt` double(11,2) DEFAULT NULL,
  KEY `fkproducto` (`fkproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_precios_productos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_productos`
--

CREATE TABLE IF NOT EXISTS `tbl_productos` (
  `idproducto` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion_prod` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `marca` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `cantidad_unitaria` int(11) NOT NULL,
  `cantidad_blt` int(11) NOT NULL,
  `cant_unidades_en_blt` int(11) NOT NULL,
  `estatus_prod` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`idproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_productos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_proveedores`
--

CREATE TABLE IF NOT EXISTS `tbl_proveedores` (
  `idproveedor` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `razon_social` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `representante_legal` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fono` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `estatus_prov` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`idproveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_proveedores`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_regalias`
--

CREATE TABLE IF NOT EXISTS `tbl_regalias` (
  `idregalia` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `descripcion` varchar(200) COLLATE utf8_spanish2_ci NOT NULL,
  `responsable` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fkproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `estatus_reg` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`idregalia`),
  KEY `fkproducto` (`fkproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_regalias`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuarios`
--

CREATE TABLE IF NOT EXISTS `tbl_usuarios` (
  `login` varchar(6) COLLATE utf8_spanish2_ci NOT NULL,
  `passw` varchar(32) COLLATE utf8_spanish2_ci NOT NULL,
  `user_name` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `nivel` int(11) NOT NULL,
  `email` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `pregunta_secreta_1` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `respuesta_secreta_1` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `pregunta_secreta_2` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `respuesta_secreta_2` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `estatus_user` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcar la base de datos para la tabla `tbl_usuarios`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_vendedores`
--

CREATE TABLE IF NOT EXISTS `tbl_vendedores` (
  `idvendedor` int(11) NOT NULL AUTO_INCREMENT,
  `rif` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `nombres` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `fono` varchar(20) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `estatus_vend` varchar(10) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`idvendedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_vendedores`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_ventas`
--

CREATE TABLE IF NOT EXISTS `tbl_ventas` (
  `idventa` int(11) NOT NULL AUTO_INCREMENT,
  `fkvendedor` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `fkcliente` int(11) NOT NULL,
  `iva` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `subtotal` double(11,2) NOT NULL,
  `total_neto` double(11,2) NOT NULL,
  `excento` double(11,2) NOT NULL,
  `estatus_venta` varchar(10) COLLATE utf8_spanish2_ci NOT NULL COMMENT 'pendiente, pagada, anulada',
  PRIMARY KEY (`idventa`),
  KEY `fkcliente` (`fkcliente`),
  KEY `fkvendedor` (`fkvendedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tbl_ventas`
--


--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `tbl_abonos`
--
ALTER TABLE `tbl_abonos`
  ADD CONSTRAINT `tbl_abonos_ibfk_1` FOREIGN KEY (`fkventa`) REFERENCES `tbl_ventas` (`idventa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_cierres_diarios_inv`
--
ALTER TABLE `tbl_cierres_diarios_inv`
  ADD CONSTRAINT `tbl_cierres_diarios_inv_ibfk_1` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_cuentas_cobrar`
--
ALTER TABLE `tbl_cuentas_cobrar`
  ADD CONSTRAINT `tbl_cuentas_cobrar_ibfk_1` FOREIGN KEY (`fkventa`) REFERENCES `tbl_ventas` (`idventa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_cuentas_pagar`
--
ALTER TABLE `tbl_cuentas_pagar`
  ADD CONSTRAINT `tbl_cuentas_pagar_ibfk_1` FOREIGN KEY (`fkventa`) REFERENCES `tbl_ventas` (`idventa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_detalles_pedidos`
--
ALTER TABLE `tbl_detalles_pedidos`
  ADD CONSTRAINT `tbl_detalles_pedidos_ibfk_2` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`),
  ADD CONSTRAINT `tbl_detalles_pedidos_ibfk_1` FOREIGN KEY (`fkpedido`) REFERENCES `tbl_pedidos` (`idpedido`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_detalles_ventas`
--
ALTER TABLE `tbl_detalles_ventas`
  ADD CONSTRAINT `tbl_detalles_ventas_ibfk_2` FOREIGN KEY (`fkventa`) REFERENCES `tbl_ventas` (`idventa`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_detalles_ventas_ibfk_1` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`);

--
-- Filtros para la tabla `tbl_fletes`
--
ALTER TABLE `tbl_fletes`
  ADD CONSTRAINT `tbl_fletes_ibfk_1` FOREIGN KEY (`fkpedido`) REFERENCES `tbl_pedidos` (`idpedido`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_nros_cuentas_vendedores`
--
ALTER TABLE `tbl_nros_cuentas_vendedores`
  ADD CONSTRAINT `tbl_nros_cuentas_vendedores_ibfk_1` FOREIGN KEY (`fkvendedor`) REFERENCES `tbl_vendedores` (`idvendedor`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_pedidos`
--
ALTER TABLE `tbl_pedidos`
  ADD CONSTRAINT `tbl_pedidos_ibfk_1` FOREIGN KEY (`fkproveedor`) REFERENCES `tbl_proveedores` (`idproveedor`);

--
-- Filtros para la tabla `tbl_precios_productos`
--
ALTER TABLE `tbl_precios_productos`
  ADD CONSTRAINT `tbl_precios_productos_ibfk_1` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tbl_regalias`
--
ALTER TABLE `tbl_regalias`
  ADD CONSTRAINT `tbl_regalias_ibfk_1` FOREIGN KEY (`fkproducto`) REFERENCES `tbl_productos` (`idproducto`);

--
-- Filtros para la tabla `tbl_ventas`
--
ALTER TABLE `tbl_ventas`
  ADD CONSTRAINT `tbl_ventas_ibfk_2` FOREIGN KEY (`fkvendedor`) REFERENCES `tbl_vendedores` (`idvendedor`),
  ADD CONSTRAINT `tbl_ventas_ibfk_1` FOREIGN KEY (`fkcliente`) REFERENCES `tbl_clientes` (`idcliente`);
